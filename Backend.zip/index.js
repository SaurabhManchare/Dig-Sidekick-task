const express = require("express");
const app = express();
const cors = require("cors");
require('dotenv').config()
const connectdb = require("./config/db");
const userRoutes = require("./routes/users");
const authRoutes = require("./routes/auth");


// middleware
app.use(express.json());
app.use(cors());


// Database Connected
connectdb()

app.get("/", function(req, res) {
    res.render("Home.ejs");
})




// routes
app.use("/api/users", userRoutes);
app.use("/api/auth", authRoutes)


app.listen(process.env.PORT, function() {
    console.log(`Server listening on ${process.env.PORT}`);
});