const mongoose = require("mongoose");

const connectdb = () => {
    mongoose.set('strictQuery', false);
    mongoose.connect(process.env.databaseone, 
        {
            useNewUrlParser : true
        }).then(() => {
            console.log("Database is connected to Server");
        }).catch((err) => {
            console.log("Error connecting");
        });


}

module.exports = connectdb;