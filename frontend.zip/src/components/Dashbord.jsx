import React from 'react'

const Dashbord = () => {

    const handleLogout = () => {
		localStorage.removeItem("token");
		window.location.reload();
	};

  return (
    <>
    <nav className="navbar navbar-light bg-light">
  <div className="container">
    <a className="navbar-brand">Welcome Saurabh</a>
    <form className="d-flex">
      <button className="btn btn-outline-success" type="submit" onClick={handleLogout}>Logout</button>
    </form>
  </div>
</nav>
    </>
  )
}

export default Dashbord