import React from 'react';
import { useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

import {
  MDBBtn,
  MDBContainer,
  MDBCard,
  MDBCardBody,
  MDBCardImage,
  MDBRow,
  MDBCol,
  MDBInput,

}
from 'mdb-react-ui-kit';

const Loginform = () => {
    const [data, setData] = useState({ email: "", password: "" });
	const [error, setError] = useState("");

	const handleChange = ({ currentTarget: input }) => {
		setData({ ...data, [input.name]: input.value });
	};

	const handleSubmit = async (e) => {
		e.preventDefault();
    console.log("ok")
		try {
			const url = "http://localhost:5000/api/auth";
			const { data: res } = await axios.post(url, data);
			localStorage.setItem("token", res.data);
			window.location = "/";
		} catch (error) {
			if (
				error.response &&
				error.response.status >= 400 &&
				error.response.status <= 500
			) {
				setError(error.response.data.message);
			}
		}
	};

  return (
    <MDBContainer className='my-5'>
      <MDBCard>

        <MDBRow className='g-0 d-flex align-items-center'>

          <MDBCol md='4'>
            <MDBCardImage src='https://mdbootstrap.com/img/new/ecommerce/vertical/004.jpg' alt='phone' className='rounded-t-5 rounded-tr-lg-0' fluid />
          </MDBCol>

          <MDBCol md='8'>
          <form onSubmit={handleSubmit}>

            <MDBCardBody>
             <MDBInput wrapperClass='mb-4' label='Email address' id='form1' type='email'
              placeholder="Email"
              name="email"
              onChange={handleChange}
              value={data.email}
              required
              />
              <MDBInput wrapperClass='mb-4' label='Password' id='form2' type='password'
              placeholder="Password"
              name="password"
              onChange={handleChange}
              value={data.password}
              required
              />
             {error && <div className='errorcolor'>{error}</div>}
              <MDBBtn className="mb-4 w-100 mt-3" type='submit'>Sign in</MDBBtn>

              

              <Link to="/signup">
              <div className='mt-5 text-center'>
              <p className='ms-5'>Don't have an account? <a href="#!" >Register here</a></p>
              </div>
					</Link>
              

            </MDBCardBody>
            </form>
          </MDBCol>

        </MDBRow>

      </MDBCard>
    </MDBContainer>
  )
}

export default Loginform